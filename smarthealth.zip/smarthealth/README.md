# SmartHealth

Offline-first clinical support for Nigerian community health workers and patients.

**Encounter flow:** translation → triage → diagnosis → referral. Patients can also talk to a voice health companion in Hausa, Pidgin or English.

## Run locally

```bash
python -m venv .venv && source .venv/bin/activate
pip install -r requirements.txt
cp .env.example .env        # then fill in the keys
FLASK_DEBUG=1 python app.py
```

Demo logins (local only): `MU2789` and `AK1001`, password `password123` unless `SEED_PASSWORD` is set.

## Environment variables

| Variable | Purpose |
| --- | --- |
| `SECRET_KEY` | **Required in production.** Signs sessions. |
| `GROQ_API_KEY` | Whisper speech-to-text |
| `LITELLM_API_KEY`, `LITELLM_BASE_URL`, `LLM_MODEL` | Language model |
| `SEED_PASSWORD` | Password for the demo workers |
| `DATABASE_URL` | Defaults to SQLite in `/tmp` |

## Production notes

- **Data is ephemeral on Vercel.** SQLite in `/tmp` is wiped between cold starts. Use a hosted Postgres via `DATABASE_URL` before real use.
- **Sessions need a stable `SECRET_KEY`** or workers are logged out on every restart.
- Replace the Tailwind CDN script with a built CSS file before launch (smaller, faster on 3G).
- The patient portal identifies people by phone number only. Add an SMS one-time code before storing real health data.
- AI output is decision support. The worker always chooses the diagnosis.
